import json
import os

import requests
from crewai import Agent, Task
from langchain.tools import tool
from bs4 import BeautifulSoup
from datetime import datetime
import asyncio
from crawl4ai import AsyncWebCrawler
from langchain_groq import ChatGroq
from langchain_groq.chat_models import ChatMessage
import os

from dotenv import load_dotenv

class BrowserTools():

    @tool("Scrape website content")
    async def scrape_and_summarize_website(website):
        """Useful to scrape the website
        based on website url and return markdown content"""
        async with AsyncWebCrawler(verbose=True) as crawler:
          result = await crawler.arun(
              url=website,
              bypass_cache=True
          )
        content = result.markdown

         # Load environment variables
        load_dotenv()


        # Initialize the Groq LLM
        groq_api_key = os.getenv("GROQ_API_KEY")
        print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>GROQ API KEY"+os.getenv("GROQ_API_KEY"))
        llm = ChatGroq(temperature=0.7, groq_api_key=groq_api_key, model_name="groq/llama-3.1-70b-versatile")
        


        summaries = []
        for chunk in content:
            agent = Agent(
                role='Principal Researcher',
                goal='Do amazing researches and summaries based on the content you are working with',
                backstory="You're a Principal Researcher at a big company and you need to do a research about a given topic.",
                allow_delegation=False,
                llm=llm)
            task = Task(
                agent=agent,
                description=f'Analyze and summarize the content bellow, make sure to include the most relevant information in the summary, return only the summary nothing else.\n\nCONTENT\n----------\n{chunk}'
            )
            summary = task.execute()
            summaries.append(summary)
        return "\n\n".join(summaries)

