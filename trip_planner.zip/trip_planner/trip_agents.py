from crewai import Agent
from langchain.llms import OpenAI

from tools.browser_tools import BrowserTools
from tools.calculator_tools import CalculatorTools
from tools.search_tools import SearchTools
from langchain_groq import ChatGroq
from langchain_groq.chat_models import ChatMessage
import os

from dotenv import load_dotenv



class TripAgents():

  def __init__(self,llm):
    # Load environment variables
    #load_dotenv()


    # Initialize the Groq LLM
    #groq_api_key = os.getenv("GROQ_API_KEY")
    #print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>GROQ API KEY"+os.getenv("GROQ_API_KEY"))
    #llm = ChatGroq(temperature=0.7, groq_api_key=groq_api_key, model_name="llama2-70b-4096")
    self.llm = llm
    
  def city_selection_agent(self):
    return Agent(
        role='City Selection Expert',
        goal='Select the best city based on weather, season, and prices',
        backstory=
        'An expert in analyzing travel data to pick ideal destinations',
        tools=[
            SearchTools.search_internet,
            BrowserTools.scrape_and_summarize_website,
        ],
        verbose=True,
        llm=self.llm
        )   

  def local_expert(self):
    return Agent(
        role='Local Expert at this city',
        goal='Provide the BEST insights about the selected city',
        backstory="""A knowledgeable local guide with extensive information
        about the city, it's attractions and customs""",
        tools=[
            SearchTools.search_internet,
            BrowserTools.scrape_and_summarize_website,
        ],
        verbose=True,
        llm=self.llm
        )

  def travel_concierge(self):
    return Agent(
        role='Amazing Travel Concierge',
        goal="""Create the most amazing travel itineraries with budget and 
        packing suggestions for the city""",
        backstory="""Specialist in travel planning and logistics with 
        decades of experience""",
        tools=[
            SearchTools.search_internet,
            BrowserTools.scrape_and_summarize_website,
            CalculatorTools.calculate,
        ],
        verbose=True,
        llm=self.llm
        )
